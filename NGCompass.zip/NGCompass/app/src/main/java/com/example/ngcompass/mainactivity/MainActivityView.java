package com.example.ngcompass.mainactivity;

public interface  MainActivityView {
}

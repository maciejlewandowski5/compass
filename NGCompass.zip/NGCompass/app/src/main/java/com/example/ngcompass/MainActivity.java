package com.example.ngcompass;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.ngcompass.mainactivity.MainActivityView;

public class MainActivity extends AppCompatActivity implements MainActivityView {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
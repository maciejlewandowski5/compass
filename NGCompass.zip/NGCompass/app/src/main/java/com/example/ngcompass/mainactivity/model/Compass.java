package com.example.ngcompass.mainactivity.model;

public class Compass {
}

# compass
demo app

 1. Prepare layout ✔️ [layout](https://www.figma.com/file/bQQCIeLbyvjftqz6w9WYDL/Untitled)
 2. Move layout to adnroid studio
 3. create compass roatition system
 4. create gps location picker
 5. connect sensors to lcations
 6. tests
 7. cleaning up
